#include<stdio.h>
int main()
{
    int array[10][10],i,j,m,n,sum=0;
    printf("Enter the number of rows:");
    scanf("%d",&m);
    printf("Enter the number of columns:");
    scanf("%d",&n);
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("\nEnter a[%d][%d] value: :",i,j);
            scanf("%d",&array[i][j]);
        }
    }
    printf("\nThe diagonal elements are:");
    if(m==n)
    for(i=0;i<m;i++)
    {
    for(j=0;j<n;j++)
        {
            if(i==j)
            {
                printf("%d", array[i][j]);
            }  
            else
            {
                printf(" ");
            }
        }
    }
    else
    {
        printf("\n matrix ia not a square");
    }
    return 0;
}
