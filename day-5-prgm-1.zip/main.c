/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int age;
    printf("Enter the age:",age);
    scanf("%d",&age);
    if(age>=18)
    {
        printf("The person's age is eligibile for voting");
    }
    else
    {
        printf("The person's age is not eligibile for voting");
    }
    return 0;
}
