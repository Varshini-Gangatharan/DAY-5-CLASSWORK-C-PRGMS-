/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int i,j,m=2,n=2,sum=0;
    int array[2][2]={{1,2},{3,4}};
    printf("\nThe diagonal elements are:");
    if(m==n)
    for(i=0;i<m;i++)
    {
    for(j=0;j<n;j++)
        {
            if(i==j)
            {
                printf("%d", array[i][j]);
            }  
            else
            {
                printf(" ");
            }
        }
    }
    else
    {
        printf("\n matrix ia not a square");
    }
    for (i = 0; i < m; ++i) 
    {
        sum = sum + array[i][i];
    }
    printf("\nThe sum of the main diagonal elements is = %d\n", sum);
    return 0;
}

