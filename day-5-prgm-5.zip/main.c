/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int i,j,m=2,n=2,sum=0,avg=0;
    int a[2][2]={{1,2},{3,4}};
    for(i=0;i< m;i++)
    {
        for(j=0;j< n;j++)
    {
    sum= sum + a[i][j];
    }
    }
    avg = sum/(m*n);
    printf("Sum = %d\n", sum);
    printf("Average = %d", avg);
}