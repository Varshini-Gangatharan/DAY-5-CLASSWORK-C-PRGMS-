/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int s1=3,s2=3,i,j;
    int arr1[]={1,2,3};
    int arr2[]={4,5,6};
    for(i=s1,j=0;j<s2;i++,j++) 
    {
        arr1[i]=arr2[j];
    }
    printf("\nConcatenated array: ");
    for(i=0;i<s1+s2;i++) 
    {
        printf("%d ",arr1[i]);
    }
    return 0;
}