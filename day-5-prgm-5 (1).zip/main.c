/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int n;
    float i,s,t;
    printf("Enter the value of n:");
    scanf("%d", &n);
    s=0;
    for (i=1;i<=n;i++)
    {
        t=1/i;
        s=s+t;
    }
    printf("The Sum of Harmonic Series is = %f",s);
}

