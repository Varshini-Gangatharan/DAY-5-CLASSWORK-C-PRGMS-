/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int prime(int);
int main()
{
    int n, res;
    printf("Enter an integer to check whether it is prime or not:");
    scanf("%d",&n);
    res=prime(n);
    if(res==1)
        printf("%d is prime.\n",n);
    else
        printf("%d is not prime.\n",n);
    return 0;
}
int prime(int a)
{
   int c;
   for(c=2;c<=a-1;c++)
   { 
      if(a%c==0)
     return 0;
   }
   return 1;
}