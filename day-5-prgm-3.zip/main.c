/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int temperature;
    printf("Enter the temperature in celcius degree:");
    scanf("%d",&temperature);
    if(temperature<0)
    {
        printf("It is a freezing weather");
    }
    else if(temperature>0 && temperature<=10)
    {
        printf("It is a very cold weather");
    }
    else if(temperature>10 && temperature<=20)
    {
        printf("It is a cold weather");
    }
    else if(temperature>20 && temperature<=30)
    {
        printf("It is a normal weather");
    }
    else if(temperature>30 && temperature<=40)
    {
        printf("It is a hot weather");
    }
    else if(temperature>=40)
    {
        printf("It is a very hot weather");
    }
    else
    {
        printf("Invalid weather entered");
    }
}
