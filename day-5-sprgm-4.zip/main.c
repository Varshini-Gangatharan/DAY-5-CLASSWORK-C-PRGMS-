/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#define MAX_100
int main()
{
    int i,max,min,size[8];
    int arr[]={1,2,3,4,5,6};
    for(i=0;i<8;i++)
    max=arr[0];
    min=arr[0];
    for(i=1;i<8;i++)
    {
        if(arr[i]>max)
        {
            max=arr[i];
        }
        if(arr[i]<min)
        {
            min=arr[i];
        }
    }
    printf("Maximum element in the array:%d\n",max);
    printf("Minimum element in the array:%d\n",min);
    return 0;
}
